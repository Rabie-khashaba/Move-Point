@extends('layouts.app')

@section('title', 'عرض المندوب')

@section('content')
<div class="nxl-content">
    <!-- [ page-header ] start -->
    <div class="page-header">
        <div class="page-header-left d-flex align-items-center">
            <div class="page-header-title">
                <h5 class="m-b-10">المندوبين</h5>
            </div>
            <ul class="breadcrumb">
                <li class="breadcrumb-item"><a href="{{ route('representatives-not-completed.index') }}">المندوبين</a></li>
            </ul>
        </div>
        <div class="page-header-right ms-auto">
            <div class="page-header-right-items d-flex align-items-center gap-2">
                @can('edit_representatives')
                    <a href="{{ route('representatives-not-completed.edit', $representative->id) }}" class="btn btn-warning d-flex align-items-center">
                        <i class="feather-edit me-2"></i>
                        <span>تعديل</span>
                    </a>
                @endcan

                @can('edit_representatives_no')
                    <form action="{{ route('representatives-not-completed.toggle-status', $representative->id) }}" method="POST">
                        @csrf
                        <button type="submit" class="btn btn-outline-{{ $representative->is_active ? 'danger' : 'success' }} d-flex align-items-center"
                                title="{{ $representative->is_active ? 'إيقاف' : 'تفعيل' }}">
                            <i class="feather-{{ $representative->is_active ? 'pause' : 'play' }} me-2"></i>
                            <span>{{ $representative->is_active ? 'إيقاف' : 'تفعيل' }}</span>
                        </button>
                    </form>
                @endcan
            </div>

        </div>
    </div>
    <!-- [ page-header ] end -->

    <!-- [ Main Content ] start -->
    <div class="main-content">
        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-header">
                        <h5 class="card-title mb-0">تفاصيل المندوب</h5>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <!-- الاسم -->
                            <div class="col-md-6 mb-3">
                                <label class="fw-bold">الاسم:</label>
                                <span>{{ $representative->name ?: 'غير محدد' }}</span>
                            </div>

                            <!-- رقم التليفون -->
                            <div class="col-md-6 mb-3">
                                <label class="fw-bold">رقم التليفون:</label>
                                <span>{{ $representative->phone ?: 'غير محدد' }}</span>
                            </div>

                            <!-- العنوان -->
                            <div class="col-md-6 mb-3">
                                <label class="fw-bold">العنوان:</label>
                                <span>{{ $representative->address ?: 'غير محدد' }}</span>
                            </div>

                            <!-- التواصل -->
                            <div class="col-md-6 mb-3">
                                <label class="fw-bold">التواصل:</label>
                                <span>{{ $representative->contact ?: 'غير محدد' }}</span>
                            </div>

                            <!-- رقم البطاقة -->
                            <div class="col-md-6 mb-3">
                                <label class="fw-bold">رقم البطاقة:</label>
                                <span>{{ $representative->national_id ?: 'غير محدد' }}</span>
                            </div>

                            <!-- المرتب -->
                            <div class="col-md-6 mb-3">
                                <label class="fw-bold">المرتب:</label>
                                <span>{{ $representative->salary ? number_format($representative->salary, 2) . ' ج.م' : 'غير محدد' }}</span>
                            </div>

                            <!-- تاريخ بداية العمل -->
                            <div class="col-md-6 mb-3">
                                <label class="fw-bold">تاريخ بداية العمل:</label>
                                @if($representative->start_date)
                                    <span class="badge bg-primary">{{ $representative->start_date->format('d/m/Y') }}</span>
                                    <small class="text-muted d-block mt-1">تم التعيين في {{ $representative->start_date->diffForHumans() }}</small>
                                @else
                                    <span class="text-muted">غير محدد</span>
                                @endif
                            </div>

                            <!-- الشركة -->
                            <div class="col-md-6 mb-3">
                                <label class="fw-bold">الشركة:</label>
                                <span class="badge bg-info">{{ $representative->company->name ?? 'غير محدد' }}</span>
                            </div>

                            <!-- رقم محفظة او حساب بنكي -->
                            <div class="col-md-6 mb-3">
                                <label class="fw-bold">رقم محفظة او حساب بنكي:</label>
                                <span>{{ $representative->bank_account ?: 'غير محدد' }}</span>
                            </div>

                            <!-- كود المندوب -->
                            <div class="col-md-6 mb-3">
                                <label class="fw-bold">كود المندوب:</label>
                                <span class="badge bg-secondary">{{ $representative->code ?: 'غير محدد' }}</span>
                            </div>

                            <!-- المحافظة -->
                            <div class="col-md-6 mb-3">
                                <label class="fw-bold">المحافظة:</label>
                                <span>{{ $representative->governorate->name ?? 'غير محدد' }}</span>
                            </div>

                            <!-- الموقع -->
                            <div class="col-md-6 mb-3">
                                <label class="fw-bold">المنطقة:</label>
                                <span>{{ $representative->location->name ?? 'غير محدد' }}</span>
                            </div>

                            <!-- الاستعلام -->
                            <div class="col-md-6 mb-3">
                                <label class="fw-bold">الاستعلام:</label>
                                <div>
                                    <span class="badge bg-{{ $representative->inquiry_checkbox ? 'success' : 'secondary' }}">
                                        {{ $representative->inquiry_checkbox ? 'نعم' : 'لا' }}
                                    </span>
                                    @if($representative->inquiry_checkbox)
                                        <small class="text-muted d-block mt-1">المندوب يحتاج إلى استعلام أو معلومات إضافية</small>
                                    @endif
                                </div>
                            </div>

                            <!-- بيانات الاستعلام -->
                            <div class="col-md-6 mb-3">
                                <label class="fw-bold">بيانات الاستعلام:</label>
                                @if($representative->inquiry_data)
                                    <div class="mt-2">
                                        <span>{{ $representative->inquiry_data }}</span>
                                    </div>
                                @else
                                    <span class="text-muted">غير محدد</span>
                                @endif
                            </div>

                            <!-- لوكيشن المنزل -->
                            <div class="col-md-12 mb-3">
                                <label class="fw-bold">لوكيشن المنزل:</label>
                                @if($representative->home_location)
                                    <div class="mt-2">
                                        <div class="d-flex align-items-start gap-2">
                                            <span class="flex-grow-1">{{ $representative->home_location }}</span>
                                            <a href="{{ $representative->home_location }}" target="_blank" class="btn btn-sm btn-outline-info">
                                                <i class="feather-map-pin me-1"></i>فتح في الخريطة
                                            </a>
                                        </div>
                                    </div>
                                @else
                                    <span class="text-muted">غير محدد</span>
                                @endif
                            </div>

                            <!-- الحالة -->
                            <div class="col-md-6 mb-3">
                                <label class="fw-bold">الحالة:</label>
                                <span class="badge bg-{{ $representative->is_active ? 'success' : 'danger' }}">
                                    {{ $representative->is_active ? 'نشط' : 'غير نشط' }}
                                </span>
                            </div>
                        </div>

                        <!-- المرفقات -->
                        @if(isset($representative->attachments_with_urls) && count($representative->attachments_with_urls) > 0)
                            <div class="row mt-4">
                                <div class="col-12">
                                    <label class="fw-bold">المرفقات:</label>
                                    <div class="row mt-2">
                                        @foreach($representative->attachments_with_urls as $attachment)
                                            @php
                                                $extension = strtolower(pathinfo($attachment['path'], PATHINFO_EXTENSION));
                                                $isImage = in_array($extension, ['jpg', 'jpeg', 'png', 'gif']);
                                            @endphp
                                            <div class="col-md-4 mb-3">
                                                <div class="card">
                                                    <div class="card-body p-3">
                                                        <div class="d-flex align-items-center mb-2">
                                                            @if($isImage)
                                                                <i class="feather-image me-2 text-success"></i>
                                                            @else
                                                                <i class="feather-file-text me-2 text-primary"></i>
                                                            @endif
                                                            <small class="text-muted fw-bold">
                                                                {{ $attachment['type'] ?? 'مرفق' }}
                                                            </small>
                                                        </div>

                                                        @if($isImage)
                                                            <div class="mb-2">
                                                                <img src="{{ $attachment['url'] }}"
                                                                     alt="معاينة المرفق"
                                                                     class="img-fluid rounded"
                                                                     style="max-height: 150px; width: 100%; object-fit: cover;">
                                                            </div>
                                                        @endif

                                                        <div class="d-flex gap-2">
                                                            <a href="{{ $attachment['url'] }}" target="_blank" class="btn btn-sm btn-outline-primary">
                                                                <i class="feather-eye me-1"></i> عرض
                                                            </a>

                                                            <a href="{{ $attachment['url'] }}" download class="btn btn-sm btn-outline-success">
                                                                <i class="feather-download me-1"></i> تحميل
                                                            </a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        @endforeach
                                    </div>


                                    </div>
                                </div>
                            </div>
                        @else
                            <div class="row mt-4">
                                <div class="col-12">
                                    <label class="fw-bold">المرفقات:</label>
                                    <div class="mt-2">
                                        <span class="text-muted">لا توجد مرفقات</span>
                                    </div>
                                </div>
                            </div>
                        @endif


                        <hr class="my-4">

                        <div class="row">
                            <div class="col-md-6">
                                <label class="fw-bold">تاريخ الإنشاء:</label>
                                <span>{{ $representative->created_at->format('d/m/Y H:i') }}</span>
                            </div>

                            <div class="col-md-6">
                                <label class="fw-bold">آخر تحديث:</label>
                                <span>{{ $representative->updated_at->format('d/m/Y H:i') }}</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- [ Main Content ] end -->
</div>
@endsection
